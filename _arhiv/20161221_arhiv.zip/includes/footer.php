	<section class="footer">
			<div class="content content_flex">
				<div class="footer__cols"><span class="footer__zagolovok">Тел.: +7 (3852) 62-33-44<br/>
E-mail:<a href="mailto:623344@mail.ru" class="link link_white"> 623344@mail.ru</a><br/>
Адрес: Алтайский край, г. Барнаул, <br/>улица Южные Мастерские, д. 14 Б </span>

				</div>
				<div class="footer__cols">
					<a href="/" class="footer__logo">
						<img src="images/logo_white.svg" alt="">
					</a>
				</div>
				<div class="footer__cols"><span class="footer__zagolovok footer__zagolovok_right">2016 &copy ООО «Типография Графика»</span>
				</div>

			</div>

		</section>
	</div>
	<!--<script src="script/Wallop.js"></script>
<script>
  var slider = document.querySelector('.Wallop');
    var Wallop = new Wallop(slider);
	function autoplay(interval) {
  var lastTime = 0;  
  
  function frame(timestamp) {
    var update = timestamp - lastTime >= interval;
  
    if (update) {
      Wallop.next();
      lastTime = timestamp;
    }
  
    requestAnimationFrame(frame);
  }

  requestAnimationFrame(frame);
};
	
	autoplay(5000);
</script>-->
<script src="script/modernizr.js"></script>
	<script src="script/myscript.js"></script>
<script src="script/parallax.js"></script>
</body>

</html>