<section class="banner-box">
					<div class="content content_nopadding">
						<div class="carousel">
							<div class="carousel-cell">
								<div class="carousel_text-block">
									<h2 class="carousel__title">Печать на офсетной печатной машине</h2>
									<h2 class="carousel__title carousel__title_orange">Heidelberg Speedmaster 52</h2>
									<p class="carousel__paragraph">Машины ряда Speedmaster SM 52 — это высокое качество при большой производительности, экономическая эффективность малых тиражей, сокращение времени переналадки, надежность производства благодаря новейшим технологиям.</p>
								</div>
								<div class="carousel__img-block">
									<img class="carousel__img" src="images/speedmaster.jpg" alt="">
								</div>
							</div>
							<div class="carousel-cell">
								<div class="carousel_text-block">
									<h2 class="carousel__title carousel__title_orange">Самоклеющаяся этикетка</h2><br/>
					<p class="carousel__paragraph">Офсетная печать на самоклеющейся бумаге Рафлатак (Raflatac), 4+0</p>
<p class="carousel__paragraph">В наличие имеются высечные штампы:<br/> 
D45, D60, D70, D80, D110, D97<br/>
Овальные штампы: 140х67, 95х65, 157х102, 90х52,<br/>
фигурные штампы различной конфигурации</p>
								</div>
								<div class="carousel__img-block">
									<img class="carousel__img" src="images/etiketka-baner.jpg" alt="">
								</div>
							</div>
						</div>
					</div>
				</section>